from setuptools import setup

setup(
    name='pixel_art',
    version='0.1',
    description='blab lbab',
    author='mein name',
    packages=['pixel_art'],
    install_requires = ['colorama']

)